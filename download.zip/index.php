<?php
// Enable error reporting to see the exact issue
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// index.php
require_once __DIR__ . '/includes/auth.php';

$db = getDB();
$user = currentUser($db);

$pageTitle = 'Home';
require_once __DIR__ . '/includes/header.php';
?>

<div class="row justify-content-center text-center my-5">
    <div class="col-lg-8">
        <h1 class="display-4 fw-bold mb-3">Small Loans. Big Impact.</h1>
        <p class="lead text-muted mb-4">Apply for a micro-loan in minutes. Track your wallet, repayments, and status — all in one place.</p>
        
        <?php if (!$user): ?>
            <div class="d-flex justify-content-center gap-3">
                <a href="/auth/register.php" class="btn btn-primary btn-lg px-4">Get Started</a>
                <a href="/auth/login.php" class="btn btn-outline-secondary btn-lg px-4">Login</a>
            </div>
        <?php else: ?>
            <div class="alert alert-success">
                Welcome back, <strong><?= e($user['full_name']) ?></strong>! 
                <a href="<?= $user['role'] === 'admin' ? '/admin/dashboard.php' : '/borrower/dashboard.php' ?>" class="alert-link ms-2">Go to Dashboard &rarr;</a>
            </div>
        <?php endif; ?>
    </div>
</div>

<div class="row text-center my-5 g-4">
    <div class="col-md-4">
        <div class="card h-100 shadow-sm border-0 p-3">
            <div class="card-body">
                <div class="text-primary fs-1 mb-3"><i class="bi bi-file-earmark-text"></i></div>
                <h4>1. Apply</h4>
                <p class="text-muted small">Choose amount and term. See interest and installment instantly.</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card h-100 shadow-sm border-0 p-3">
            <div class="card-body">
                <div class="text-success fs-1 mb-3"><i class="bi bi-check-circle"></i></div>
                <h4>2. Get Approved</h4>
                <p class="text-muted small">Admin reviews your request. Funds go straight to your digital wallet.</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card h-100 shadow-sm border-0 p-3">
            <div class="card-body">
                <div class="text-warning fs-1 mb-3"><i class="bi bi-calendar-check"></i></div>
                <h4>3. Repay Easily</h4>
                <p class="text-muted small">Clear schedule. Record payments via wallet or GCash and track everything.</p>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>