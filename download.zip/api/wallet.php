<?php
// api/wallet.php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth.php';

// Check if user is logged in
if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized. Please login first.']);
    exit;
}

$db = getDB();
$userId = $_SESSION['user_id'];

// Get wallet balance
$balance = getWalletBalance($db, $userId);

// Get recent transactions
$stmt = $db->prepare("SELECT type, amount, payment_method, reference_no, description, created_at FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT 20");
$stmt->execute([$userId]);
$transactions = $stmt->fetchAll();

echo json_encode([
    'status' => 'success',
    'user_id' => $userId,
    'wallet_balance' => $balance,
    'transactions' => $transactions
]);