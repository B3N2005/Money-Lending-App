<?php
// api/repayment.php
header('Content-Type: application/json');
require_once __DIR__ . '/../includes/auth.php';

if (empty($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed. Use POST.']);
    exit;
}

$db = getDB();
$userId = $_SESSION['user_id'];

// Read incoming JSON or POST data
$input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
$scheduleId = $input['schedule_id'] ?? '';
$loanId = $input['loan_id'] ?? '';
$paymentMethod = strtoupper($input['payment_method'] ?? 'WALLET'); // WALLET or GCASH
$refNo = trim($input['reference_no'] ?? generateTxReference());

if (!$scheduleId || !$loanId) {
    echo json_encode(['error' => 'Missing schedule_id or loan_id']);
    exit;
}

$stmt = $db->prepare("SELECT * FROM repayment_schedules WHERE schedule_id = ? AND status = 'PENDING'");
$stmt->execute([$scheduleId]);
$sched = $stmt->fetch();

$stmtLoan = $db->prepare("SELECT * FROM loans WHERE loan_id = ? AND borrower_id = ?");
$stmtLoan->execute([$loanId, $userId]);
$loan = $stmtLoan->fetch();

if (!$sched || !$loan) {
    echo json_encode(['error' => 'Invalid installment schedule or loan']);
    exit;
}

$amount = (float)$sched['installment_amount'];

// If paying by wallet, check balance
if ($paymentMethod === 'WALLET') {
    $balance = getWalletBalance($db, $userId);
    if ($balance < $amount) {
        echo json_encode(['error' => 'Insufficient wallet balance']);
        exit;
    }
}

try {
    $db->beginTransaction();

    if ($paymentMethod === 'WALLET') {
        $stmt = $db->prepare("UPDATE wallets SET balance = balance - ? WHERE borrower_id = ?");
        $stmt->execute([$amount, $userId]);
    }

    // Mark schedule paid
    $stmt = $db->prepare("UPDATE repayment_schedules SET status = 'PAID', paid_at = NOW() WHERE schedule_id = ?");
    $stmt->execute([$scheduleId]);

    // Record transaction
    $txId = generateUUID();
    $stmt = $db->prepare("INSERT INTO transactions (transaction_id, loan_id, user_id, type, amount, payment_method, reference_no, description) VALUES (?,?,?,?,'REPAYMENT',?,?,?)");
    $stmt->execute([
        $txId, 
        $loanId, 
        $userId, 
        $amount, 
        $paymentMethod, 
        $refNo, 
        ucfirst(strtolower($paymentMethod)) . ' Installment #' . $sched['installment_number'] . ' payment'
    ]);

    // Credit pool
    $poolBalance = getPoolBalance($db);
    $newPool = $poolBalance + $amount;
    $entryId = generateUUID();
    $stmt = $db->prepare("INSERT INTO lending_pool_ledger (entry_id, type, amount, balance_after, reference_id, notes) VALUES (?,'REPAYMENT',?,?,?,?)");
    $stmt->execute([$entryId, $amount, $newPool, $loanId, 'Repayment installment #' . $sched['installment_number']]);

    // Check if loan completed
    $stmt = $db->prepare("SELECT COUNT(*) FROM repayment_schedules WHERE loan_id = ? AND status = 'PENDING'");
    $stmt->execute([$loanId]);
    if ((int)$stmt->fetchColumn() === 0) {
        $stmt = $db->prepare("UPDATE loans SET status = 'COMPLETED' WHERE loan_id = ?");
        $stmt->execute([$loanId]);
        
        $stmtApp = $db->prepare("SELECT application_id FROM loans WHERE loan_id = ?");
        $stmtApp->execute([$loanId]);
        $loanData = $stmtApp->fetch();
        if ($loanData) {
            $stmt = $db->prepare("UPDATE loan_applications SET status = 'CLOSED' WHERE application_id = ?");
            $stmt->execute([$loanData['application_id']]);
        }
    } else {
        $stmt = $db->prepare("UPDATE loans SET status = 'ACTIVE' WHERE loan_id = ? AND status = 'DISBURSED'");
        $stmt->execute([$loanId]);
    }

    $db->commit();

    echo json_encode([
        'status' => 'success',
        'message' => 'Repayment processed successfully',
        'reference_no' => $refNo,
        'amount_paid' => $amount
    ]);

} catch (Exception $e) {
    $db->rollBack();
    http_response_code(500);
    echo json_encode(['error' => 'Transaction failed: ' . $e->getMessage()]);
}