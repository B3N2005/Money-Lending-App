<?php
// Database configuration for XAMPP (MySQL/MariaDB)
define('DB_HOST', 'sql313.infinityfree.com');
define('DB_NAME', 'if0_43236489_microlend');
define('DB_USER', 'if0_43236489');
define('DB_PASS', '5rX3oYWIxk'); // Default XAMPP has empty password
define('DB_CHARSET', 'utf8mb4');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die('Database connection failed. Please check config/database.php and make sure the microlend database exists.<br>Error: ' . htmlspecialchars($e->getMessage()));
        }
    }
    return $pdo;
}
