<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole('admin');
$db = getDB();

$poolBalance = getPoolBalance($db);

$stmt = $db->query("SELECT COUNT(*) FROM loan_applications WHERE status = 'PENDING_REVIEW'");
$pendingApps = (int)$stmt->fetchColumn();

$stmt = $db->query("SELECT COUNT(*) FROM loans WHERE status IN ('DISBURSED','ACTIVE')");
$activeLoans = (int)$stmt->fetchColumn();

$stmt = $db->query("SELECT COUNT(*) FROM repayment_schedules WHERE status = 'PENDING' AND due_date < CURDATE()");
$overdue = (int)$stmt->fetchColumn();

$stmt = $db->query("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type = 'DISBURSEMENT'");
$totalDisbursed = (float)$stmt->fetchColumn();

$stmt = $db->query("SELECT COALESCE(SUM(amount),0) FROM transactions WHERE type = 'REPAYMENT'");
$totalRepaid = (float)$stmt->fetchColumn();

// Recent pending applications
$stmt = $db->query("
    SELECT a.*, u.full_name, u.username 
    FROM loan_applications a 
    JOIN users u ON a.borrower_id = u.user_id 
    WHERE a.status = 'PENDING_REVIEW' 
    ORDER BY a.created_at ASC 
    LIMIT 8
");
$pendingList = $stmt->fetchAll();

$pageTitle = 'Admin Dashboard';
require_once __DIR__ . '/../includes/header.php';
?>

<h2 class="mb-4">Admin Dashboard</h2>

<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card stat-card success h-100">
            <div class="card-body">
                <div class="stat-label">Lending Pool</div>
                <div class="stat-value"><?= formatMoney($poolBalance) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card warning h-100">
            <div class="card-body">
                <div class="stat-label">Pending Applications</div>
                <div class="stat-value"><?= $pendingApps ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card info h-100">
            <div class="card-body">
                <div class="stat-label">Active Loans</div>
                <div class="stat-value"><?= $activeLoans ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card danger h-100">
            <div class="card-body">
                <div class="stat-label">Overdue Installments</div>
                <div class="stat-value"><?= $overdue ?></div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="stat-label">Total Disbursed</div>
                <div class="h4 mb-0"><?= formatMoney($totalDisbursed) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <div class="stat-label">Total Repaid</div>
                <div class="h4 mb-0 text-success"><?= formatMoney($totalRepaid) ?></div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span>Pending Applications</span>
        <a href="/microlend/admin/applications.php" class="btn btn-sm btn-outline-primary">View All</a>
    </div>
    <div class="card-body p-0">
        <?php if (empty($pendingList)): ?>
            <p class="p-3 text-secondary mb-0">No pending applications.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Borrower</th>
                            <th>Amount</th>
                            <th>Term</th>
                            <th>Submitted</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pendingList as $app): ?>
                            <tr>
                                <td>
                                    <strong><?= e($app['full_name']) ?></strong>
                                    <div class="small text-muted">@<?= e($app['username']) ?></div>
                                </td>
                                <td><?= formatMoney($app['amount']) ?></td>
                                <td><?= (int)$app['repayment_term'] ?> mo</td>
                                <td class="small"><?= date('M j, Y H:i', strtotime($app['created_at'])) ?></td>
                                <td class="text-end">
                                    <a href="/admin/applications.php?id=<?= e($app['application_id']) ?>" class="btn btn-sm btn-primary">Review</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
