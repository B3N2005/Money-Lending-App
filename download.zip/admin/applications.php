<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole('admin');
$db = getDB();

// Handle decision
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['application_id'], $_POST['decision'])) {
    $appId = $_POST['application_id'];
    $decision = $_POST['decision'];

    $stmt = $db->prepare("SELECT * FROM loan_applications WHERE application_id = ? AND status = 'PENDING_REVIEW'");
    $stmt->execute([$appId]);
    $app = $stmt->fetch();

    if ($app && in_array($decision, ['APPROVE', 'REJECT'])) {
        try {
            $db->beginTransaction();

            if ($decision === 'REJECT') {
                $stmt = $db->prepare("UPDATE loan_applications SET status = 'REJECTED' WHERE application_id = ?");
                $stmt->execute([$appId]);
                $db->commit();
                flash('success', 'Application rejected.');
            } else {
                // Approve → create loan + schedule
                $calc = calculateFlatInterest((float)$app['amount'], (int)$app['repayment_term'], 10.0);
                $loanId = generateUUID();

                $stmt = $db->prepare("UPDATE loan_applications SET status = 'APPROVED' WHERE application_id = ?");
                $stmt->execute([$appId]);

                $stmt = $db->prepare("INSERT INTO loans (loan_id, application_id, borrower_id, approved_principal, flat_interest, total_repayment, interest_rate, status) VALUES (?,?,?,?,?,?,?,'APPROVED')");
                $stmt->execute([
                    $loanId,
                    $appId,
                    $app['borrower_id'],
                    $calc['principal'],
                    $calc['interest'],
                    $calc['total'],
                    $calc['rate']
                ]);

                // Generate schedule
                $start = new DateTime('first day of next month');
                foreach ($calc['installments'] as $i => $amt) {
                    $due = clone $start;
                    $due->modify('+' . $i . ' months');
                    $schedId = generateUUID();
                    $stmt = $db->prepare("INSERT INTO repayment_schedules (schedule_id, loan_id, installment_number, due_date, installment_amount, status) VALUES (?,?,?,?,?,'PENDING')");
                    $stmt->execute([$schedId, $loanId, $i + 1, $due->format('Y-m-d'), $amt]);
                }

                $db->commit();
                flash('success', 'Application approved. Loan and repayment schedule created. You can now disburse.');
            }
        } catch (Exception $e) {
            $db->rollBack();
            flash('danger', 'Action failed: ' . $e->getMessage());
        }
    } else {
        flash('danger', 'Invalid application or already processed.');
    }
    header('Location: /admin/applications.php' . (isset($_GET['id']) ? '?id=' . urlencode($_GET['id']) : ''));
    exit;
}

// Handle disbursement
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['disburse_loan_id'])) {
    $loanId = $_POST['disburse_loan_id'];

    $stmt = $db->prepare("SELECT l.*, a.application_id FROM loans l JOIN loan_applications a ON l.application_id = a.application_id WHERE l.loan_id = ? AND l.status = 'APPROVED'");
    $stmt->execute([$loanId]);
    $loan = $stmt->fetch();

    if ($loan) {
        $stmt = $db->prepare("SELECT transaction_id FROM transactions WHERE loan_id = ? AND type = 'DISBURSEMENT'");
        $stmt->execute([$loanId]);
        if ($stmt->fetch()) {
            flash('danger', 'This loan has already been disbursed.');
        } else {
            $poolBalance = getPoolBalance($db);
            if ($poolBalance < (float)$loan['approved_principal']) {
                flash('danger', 'Disbursement cannot be completed because the lending pool has insufficient funds.');
            } else {
                try {
                    $db->beginTransaction();

                    // Credit borrower wallet
                    $stmt = $db->prepare("UPDATE wallets SET balance = balance + ? WHERE borrower_id = ?");
                    $stmt->execute([$loan['approved_principal'], $loan['borrower_id']]);

                    // Debit pool
                    $newPool = $poolBalance - (float)$loan['approved_principal'];
                    $entryId = generateUUID();
                    $stmt = $db->prepare("INSERT INTO lending_pool_ledger (entry_id, type, amount, balance_after, reference_id, notes) VALUES (?,'DISBURSEMENT',?,?,?,?)");
                    $stmt->execute([$entryId, $loan['approved_principal'], $newPool, $loanId, 'Disbursement of loan']);

                    // Transaction record with Personal Reference Number
                    $txId = generateUUID();
                    $txRef = generateTxReference();
                    $stmt = $db->prepare("INSERT INTO transactions (transaction_id, loan_id, user_id, type, amount, payment_method, reference_no, description) VALUES (?,?,?,'DISBURSEMENT',?,'WALLET',?,?)");
                    $stmt->execute([$txId, $loanId, $loan['borrower_id'], $loan['approved_principal'], $txRef, 'Loan disbursement to wallet']);

                    // Update statuses
                    $stmt = $db->prepare("UPDATE loans SET status = 'DISBURSED', disbursed_at = NOW() WHERE loan_id = ?");
                    $stmt->execute([$loanId]);
                    $stmt = $db->prepare("UPDATE loan_applications SET status = 'DISBURSED' WHERE application_id = ?");
                    $stmt->execute([$loan['application_id']]);

                    $db->commit();
                    flash('success', 'Loan disbursed successfully. Funds credited to borrower wallet.');
                } catch (Exception $e) {
                    $db->rollBack();
                    flash('danger', 'Disbursement failed.');
                }
            }
        }
    } else {
        flash('danger', 'Loan not found or not in APPROVED status.');
    }
    header('Location: /admin/applications.php');
    exit;
}

// Single application view
$single = null;
if (!empty($_GET['id'])) {
    $stmt = $db->prepare("
        SELECT a.*, u.full_name, u.username, u.email,
               l.loan_id, l.status AS loan_status, l.approved_principal, l.flat_interest, l.total_repayment
        FROM loan_applications a
        JOIN users u ON a.borrower_id = u.user_id
        LEFT JOIN loans l ON l.application_id = a.application_id
        WHERE a.application_id = ?
    ");
    $stmt->execute([$_GET['id']]);
    $single = $stmt->fetch();
}

// List
$statusFilter = $_GET['status'] ?? 'PENDING_REVIEW';
$validStatuses = ['PENDING_REVIEW', 'APPROVED', 'REJECTED', 'DISBURSED', 'CLOSED', 'ALL'];
if (!in_array($statusFilter, $validStatuses)) $statusFilter = 'PENDING_REVIEW';

if ($statusFilter === 'ALL') {
    $stmt = $db->query("
        SELECT a.*, u.full_name, u.username 
        FROM loan_applications a 
        JOIN users u ON a.borrower_id = u.user_id 
        ORDER BY a.created_at DESC 
        LIMIT 50
    ");
} else {
    $stmt = $db->prepare("
        SELECT a.*, u.full_name, u.username 
        FROM loan_applications a 
        JOIN users u ON a.borrower_id = u.user_id 
        WHERE a.status = ? 
        ORDER BY a.created_at DESC 
        LIMIT 50
    ");
    $stmt->execute([$statusFilter]);
}
$list = $stmt->fetchAll();

$pageTitle = 'Loan Applications';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0">Loan Applications</h2>
    <div class="btn-group">
        <?php foreach (['PENDING_REVIEW' => 'Pending', 'APPROVED' => 'Approved', 'DISBURSED' => 'Disbursed', 'REJECTED' => 'Rejected', 'ALL' => 'All'] as $val => $label): ?>
            <a href="?status=<?= $val ?>" class="btn btn-sm <?= $statusFilter === $val ? 'btn-primary' : 'btn-outline-primary' ?>"><?= $label ?></a>
        <?php endforeach; ?>
    </div>
</div>

<?php if ($single): ?>
<div class="card mb-4 border-primary">
    <div class="card-header bg-primary text-white">
        Application Review — <?= e($single['full_name']) ?>
    </div>
    <div class="card-body">
        <div class="row mb-3">
            <div class="col-md-3"><div class="stat-label">Amount</div><div class="h5"><?= formatMoney($single['amount']) ?></div></div>
            <div class="col-md-3"><div class="stat-label">Term</div><div class="h5"><?= (int)$single['repayment_term'] ?> months</div></div>
            <div class="col-md-3"><div class="stat-label">Status</div><div><?= statusBadge($single['status']) ?></div></div>
            <div class="col-md-3"><div class="stat-label">Submitted</div><div><?= date('M j, Y H:i', strtotime($single['created_at'])) ?></div></div>
        </div>
        <p class="mb-1"><strong>Borrower:</strong> <?= e($single['full_name']) ?> (@<?= e($single['username']) ?>)</p>
        <p class="mb-3"><strong>Email:</strong> <?= e($single['email']) ?></p>

        <?php if ($single['status'] === 'PENDING_REVIEW'): ?>
            <?php
            $preview = calculateFlatInterest((float)$single['amount'], (int)$single['repayment_term']);
            ?>
            <div class="preview-box mb-3">
                <strong>If approved (flat 10%):</strong>
                Interest <?= formatMoney($preview['interest']) ?> ·
                Total <?= formatMoney($preview['total']) ?> ·
                Monthly ≈ <?= formatMoney($preview['installment']) ?>
            </div>
            <form method="post" class="d-inline">
                <input type="hidden" name="application_id" value="<?= e($single['application_id']) ?>">
                <button type="submit" name="decision" value="APPROVE" class="btn btn-success me-2">Approve</button>
                <button type="submit" name="decision" value="REJECT" class="btn btn-outline-danger">Reject</button>
            </form>
        <?php elseif ($single['status'] === 'APPROVED' && $single['loan_id']): ?>
            <div class="alert alert-info">
                Loan created. Principal: <?= formatMoney($single['approved_principal']) ?> ·
                Interest: <?= formatMoney($single['flat_interest']) ?> ·
                Total: <?= formatMoney($single['total_repayment']) ?>
            </div>
            <form method="post" class="d-inline">
                <input type="hidden" name="disburse_loan_id" value="<?= e($single['loan_id']) ?>">
                <button type="submit" class="btn btn-success">
                    <i class="bi bi-cash"></i> Disburse Now
                </button>
            </form>
            <p class="small text-muted mt-2 mb-0">Current pool balance: <?= formatMoney(getPoolBalance($db)) ?></p>
        <?php elseif ($single['loan_status']): ?>
            <p>Loan status: <?= statusBadge($single['loan_status']) ?></p>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-body p-0">
        <?php if (empty($list)): ?>
            <p class="p-3 text-secondary mb-0">No applications found.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>Borrower</th>
                            <th>Amount</th>
                            <th>Term</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($list as $app): ?>
                            <tr class="<?= (!empty($_GET['id']) && $_GET['id'] === $app['application_id']) ? 'table-active' : '' ?>">
                                <td>
                                    <strong><?= e($app['full_name']) ?></strong>
                                    <div class="small text-muted">@<?= e($app['username']) ?></div>
                                </td>
                                <td><?= formatMoney($app['amount']) ?></td>
                                <td><?= (int)$app['repayment_term'] ?> mo</td>
                                <td><?= statusBadge($app['status']) ?></td>
                                <td class="small"><?= date('M j, Y', strtotime($app['created_at'])) ?></td>
                                <td class="text-end">
                                    <a href="?id=<?= e($app['application_id']) ?>&status=<?= e($statusFilter) ?>" class="btn btn-sm btn-outline-primary">View</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>