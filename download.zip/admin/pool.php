<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole('admin');
$db = getDB();

$poolBalance = getPoolBalance($db);

$stmt = $db->query("SELECT * FROM lending_pool_ledger ORDER BY created_at DESC, entry_id DESC LIMIT 100");
$ledger = $stmt->fetchAll();

$pageTitle = 'Lending Pool';
require_once __DIR__ . '/../includes/header.php';
?>

<h2 class="mb-4">Lending Pool</h2>

<div class="card mb-4">
    <div class="card-body text-center py-4">
        <div class="stat-label">Current Available Balance</div>
        <div class="wallet-balance"><?= formatMoney($poolBalance) ?></div>
        <p class="text-secondary small mb-0">Pool is debited on disbursement and credited on borrower repayments.</p>
    </div>
</div>

<div class="card">
    <div class="card-header">Pool Ledger (latest 100 entries)</div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Amount</th>
                        <th>Balance After</th>
                        <th>Notes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($ledger as $entry): ?>
                        <tr>
                            <td class="small"><?= date('M j, Y H:i', strtotime($entry['created_at'])) ?></td>
                            <td>
                                <?php
                                $badge = match($entry['type']) {
                                    'INITIAL' => 'secondary',
                                    'DISBURSEMENT' => 'danger',
                                    'REPAYMENT' => 'success',
                                    default => 'info'
                                };
                                ?>
                                <span class="badge bg-<?= $badge ?>"><?= e($entry['type']) ?></span>
                            </td>
                            <td class="<?= $entry['type'] === 'DISBURSEMENT' ? 'text-danger' : ($entry['type'] === 'REPAYMENT' ? 'text-success' : '') ?>">
                                <?= $entry['type'] === 'DISBURSEMENT' ? '−' : '+' ?><?= formatMoney($entry['amount']) ?>
                            </td>
                            <td class="fw-semibold"><?= formatMoney($entry['balance_after']) ?></td>
                            <td class="small text-muted"><?= e($entry['notes'] ?? '—') ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
