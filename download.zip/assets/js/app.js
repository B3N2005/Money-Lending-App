// Simple live loan calculator for apply form
document.addEventListener('DOMContentLoaded', function () {
    const amountInput = document.getElementById('amount');
    const termInput = document.getElementById('repayment_term');
    const preview = document.getElementById('loan-preview');

    if (amountInput && termInput && preview) {
        function updatePreview() {
            const principal = parseFloat(amountInput.value) || 0;
            const term = parseInt(termInput.value) || 1;
            const rate = 10; // flat 10%

            if (principal > 0 && term > 0) {
                const interest = Math.round(principal * (rate / 100) * 100) / 100;
                const total = Math.round((principal + interest) * 100) / 100;
                const installment = Math.round((total / term) * 100) / 100;

                preview.innerHTML = `
                    <div class="row g-2 small">
                        <div class="col-6">Principal</div><div class="col-6 text-end fw-semibold">₱${principal.toLocaleString(undefined,{minimumFractionDigits:2})}</div>
                        <div class="col-6">Flat Interest (10%)</div><div class="col-6 text-end">₱${interest.toLocaleString(undefined,{minimumFractionDigits:2})}</div>
                        <div class="col-6">Total Repayment</div><div class="col-6 text-end fw-bold text-success">₱${total.toLocaleString(undefined,{minimumFractionDigits:2})}</div>
                        <div class="col-6">Monthly Installment</div><div class="col-6 text-end fw-bold">₱${installment.toLocaleString(undefined,{minimumFractionDigits:2})}</div>
                    </div>`;
                preview.classList.remove('d-none');
            } else {
                preview.classList.add('d-none');
            }
        }
        amountInput.addEventListener('input', updatePreview);
        termInput.addEventListener('input', updatePreview);
        updatePreview();
    }
});
