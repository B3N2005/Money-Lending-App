<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';
$db = getDB();
$user = currentUser($db);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle ?? 'MicroLend') ?> — Micro-Lending Platform</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="/assets/css/style.css" rel="stylesheet">
<link rel="icon" type="image/jpeg" href="/Rare.jpg">
    </head>
<body>
<nav class="navbar navbar-expand-lg navbar-light sticky-top">
    <div class="container">
<a class="navbar-brand d-flex align-items-center fw-bold" href="/index.php">
    <span class="rounded-circle bg-success text-white d-inline-flex justify-content-center align-items-center me-2" style="width: 36px; height: 36px;">
        <i class="bi bi-cash-coin"></i>
    </span>
    MicroLend
</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navMain">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navMain">
            <ul class="navbar-nav me-auto">
                <?php if ($user): ?>
                    <?php if ($user['role'] === 'borrower'): ?>
                        <li class="nav-item"><a class="nav-link" href="/borrower/dashboard.php">Dashboard</a></li>
                        <li class="nav-item"><a class="nav-link" href="/borrower/apply.php">Apply Loan</a></li>
                        <li class="nav-item"><a class="nav-link" href="/borrower/wallet.php">Wallet</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="/admin/dashboard.php">Admin Dashboard</a></li>
                        <li class="nav-item"><a class="nav-link" href="/admin/applications.php">Applications</a></li>
                        <li class="nav-item"><a class="nav-link" href="/admin/pool.php">Lending Pool</a></li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
            <ul class="navbar-nav ms-auto align-items-lg-center">
                <?php if ($user): ?>
                    <?php if ($user['role'] === 'borrower'): ?>
                        <li class="nav-item me-3">
                            <span class="text-success fw-semibold">
                                <i class="bi bi-wallet2"></i>
                                <?= formatMoney(getWalletBalance($db, $user['user_id'])) ?>
                            </span>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle"></i> <?= e($user['full_name']) ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><span class="dropdown-item-text small text-muted"><?= e($user['role']) ?></span></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="/auth/logout.php">Logout</a></li>
                        </ul>
                    </li>
                <?php else: ?>
                    <li class="nav-item"><a class="nav-link" href="/auth/login.php">Login</a></li>
                    <li class="nav-item"><a class="btn btn-primary btn-sm ms-2" href="/auth/register.php">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>

<main class="container py-4">
<?php
$flash = getFlash();
if ($flash):
?>
    <div class="alert alert-<?= e($flash['type']) ?> alert-dismissible fade show" role="alert">
        <?= e($flash['message']) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>
