</main>

<footer class="text-center py-4 mt-5">
    <div class="container">
        <p class="mb-0">&copy; <?= date('Y') ?> MicroLend — Loan Lifecycle & Digital Wallet Module</p>
        <p class="small text-muted">FRD-MICROLEND-2026-V1.0 · Built for XAMPP / PHP</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/assets/js/app.js"></script>
<script>
    // Disable right-click context menu
   // document.addEventListener('contextmenu', event => event.preventDefault());

    // Disable F12, Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+U
   /* document.addEventListener('keydown', function(event) {
        if (
            event.key === 'F12' || 
            (event.ctrlKey && event.shiftKey && (event.key === 'I' || event.key === 'J' || event.key === 'C')) || 
            (event.ctrlKey && event.key === 'U')
        ) {
            event.preventDefault();
            return false;
        }
    }); */
</script>
<script>
    setTimeout(function() {
        let alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            let bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 4000);
</script>
</body>
</html>
