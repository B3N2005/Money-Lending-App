<?php
/**
 * Core helper functions for Micro-Lending Platform
 */

function generateUUID(): string {
    $data = random_bytes(16);
    $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

/**
 * Generate a unique Personal Reference Number for transactions
 */
function generateTxReference(): string {
    return 'REF-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6)) . '-' . rand(1000, 9999);
}

function e(?string $value): string {
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

function formatMoney($amount): string {
    return '₱' . number_format((float)$amount, 2);
}

function flash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash(): ?array {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Flat interest calculation
 * Interest = Principal * (rate/100)
 * Total = Principal + Interest
 * Monthly installment = Total / term
 */
function calculateFlatInterest(float $principal, int $termMonths, float $ratePercent = 10.0): array {
    $interest = round($principal * ($ratePercent / 100), 2);
    $total = round($principal + $interest, 2);
    $installment = round($total / $termMonths, 2);
    
    // Adjust last installment so sum is exact
    $installments = array_fill(0, $termMonths, $installment);
    $sum = $installment * $termMonths;
    $diff = round($total - $sum, 2);
    if (abs($diff) > 0.001) {
        $installments[$termMonths - 1] = round($installments[$termMonths - 1] + $diff, 2);
    }
    
    return [
        'principal' => $principal,
        'interest'  => $interest,
        'total'     => $total,
        'rate'      => $ratePercent,
        'term'      => $termMonths,
        'installment'  => $installment,
        'installments' => $installments
    ];
}

function getPoolBalance(PDO $db): float {
    $stmt = $db->query("SELECT balance_after FROM lending_pool_ledger ORDER BY created_at DESC, entry_id DESC LIMIT 1");
    $row = $stmt->fetch();
    return $row ? (float)$row['balance_after'] : 0.00;
}

function requireLogin(): void {
    if (empty($_SESSION['user_id'])) {
        header('Location: /auth/login.php');
        exit;
    }
}

function requireRole(string $role): void {
    requireLogin();
    if (($_SESSION['role'] ?? '') !== $role) {
        flash('danger', 'You are not authorized to access that page.');
        header('Location: /index.php');
        exit;
    }
}

function currentUser(PDO $db): ?array {
    if (empty($_SESSION['user_id'])) return null;
    $stmt = $db->prepare("SELECT user_id, username, email, full_name, role, status FROM users WHERE user_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    return $stmt->fetch() ?: null;
}

function getWalletBalance(PDO $db, string $borrowerId): float {
    $stmt = $db->prepare("SELECT balance FROM wallets WHERE borrower_id = ?");
    $stmt->execute([$borrowerId]);
    $row = $stmt->fetch();
    return $row ? (float)$row['balance'] : 0.00;
}

function statusBadge(string $status): string {
    $map = [
        'PENDING_REVIEW' => 'warning',
        'APPROVED'       => 'info',
        'REJECTED'       => 'danger',
        'DISBURSED'      => 'success',
        'ACTIVE'         => 'success',
        'COMPLETED'      => 'secondary',
        'DEFAULTED'      => 'danger',
        'PENDING'        => 'warning',
        'PAID'           => 'success',
        'OVERDUE'        => 'danger',
        'PARTIAL'        => 'info',
        'CLOSED'         => 'secondary',
        'TRANSFER_OUT'   => 'warning',
        'TRANSFER_IN'    => 'success',
        'BILL_PAYMENT'   => 'danger',
    ];
    $class = $map[$status] ?? 'secondary';
    return '<span class="badge bg-' . $class . '">' . e(str_replace('_', ' ', $status)) . '</span>';
}