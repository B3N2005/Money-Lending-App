<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole('borrower');
$db = getDB();
$userId = $_SESSION['user_id'];

$scheduleId = $_POST['schedule_id'] ?? $_GET['schedule_id'] ?? '';
$loanId = $_POST['loan_id'] ?? $_GET['loan_id'] ?? '';

if (!$scheduleId || !$loanId) {
    flash('danger', 'Invalid repayment schedule.');
    header('Location: /borrower/dashboard.php');
    exit;
}

$stmt = $db->prepare("SELECT * FROM repayment_schedules WHERE schedule_id = ? AND status = 'PENDING'");
$stmt->execute([$scheduleId]);
$sched = $stmt->fetch();

if (!$sched) {
    flash('danger', 'Installment not found or already paid.');
    header('Location: /borrower/schedule.php?loan_id=' . urlencode($loanId));
    exit;
}

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_gcash'])) {
    $refNo = trim($_POST['reference_no'] ?? '');

    if (strlen($refNo) < 5) {
        $errors[] = 'Please enter a valid GCash Reference Number.';
    }

    $stmtCheck = $db->prepare("SELECT transaction_id FROM transactions WHERE reference_no = ?");
    $stmtCheck->execute([$refNo]);
    if ($stmtCheck->fetch()) {
        $errors[] = 'This GCash reference number has already been used.';
    }

    if (empty($errors)) {
        try {
            $db->beginTransaction();

            $stmt = $db->prepare("UPDATE repayment_schedules SET status = 'PAID', paid_at = NOW() WHERE schedule_id = ?");
            $stmt->execute([$scheduleId]);

            $txId = generateUUID();
            $stmt = $db->prepare("INSERT INTO transactions (transaction_id, loan_id, user_id, type, amount, payment_method, reference_no, description) VALUES (?,?,?,?,'REPAYMENT',?,?,?)");
            $stmt->execute([
                $txId, 
                $loanId, 
                $userId, 
                $sched['installment_amount'], 
                'GCASH', 
                $refNo, 
                'GCash Installment #' . $sched['installment_number'] . ' payment'
            ]);

            $poolBalance = getPoolBalance($db);
            $newPool = $poolBalance + (float)$sched['installment_amount'];
            $entryId = generateUUID();
            $stmt = $db->prepare("INSERT INTO lending_pool_ledger (entry_id, type, amount, balance_after, reference_id, notes) VALUES (?,'REPAYMENT',?,?,?,?)");
            $stmt->execute([$entryId, $sched['installment_amount'], $newPool, $loanId, 'GCash Repayment installment #' . $sched['installment_number']]);

            $stmt = $db->prepare("SELECT COUNT(*) FROM repayment_schedules WHERE loan_id = ? AND status = 'PENDING'");
            $stmt->execute([$loanId]);
            if ((int)$stmt->fetchColumn() === 0) {
                $stmt = $db->prepare("UPDATE loans SET status = 'COMPLETED' WHERE loan_id = ?");
                $stmt->execute([$loanId]);
                
                $stmtApp = $db->prepare("SELECT application_id FROM loans WHERE loan_id = ?");
                $stmtApp->execute([$loanId]);
                $loanData = $stmtApp->fetch();
                if ($loanData) {
                    $stmt = $db->prepare("UPDATE loan_applications SET status = 'CLOSED' WHERE application_id = ?");
                    $stmt->execute([$loanData['application_id']]);
                }
            } else {
                $stmt = $db->prepare("UPDATE loans SET status = 'ACTIVE' WHERE loan_id = ? AND status = 'DISBURSED'");
                $stmt->execute([$loanId]);
            }

            $db->commit();
            flash('success', 'GCash payment of ' . formatMoney($sched['installment_amount']) . ' submitted successfully!');
            header('Location: /borrower/schedule.php?loan_id=' . urlencode($loanId));
            exit;

        } catch (Exception $e) {
            $db->rollBack();
            $errors[] = 'Failed to process GCash payment. Please try again.';
        }
    }
}

$pageTitle = 'Pay via GCash';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0">GCash Payment — Installment #<?= (int)$sched['installment_number'] ?></h4>
            </div>
            <div class="card-body p-4">
                <div class="alert alert-info">
                    <strong>Amount Due:</strong> <span class="h5 text-success"><?= formatMoney($sched['installment_amount']) ?></span><br>
                    <small>Send exact amount to our GCash account, then enter your reference number.</small>
                </div>

                <div class="card bg-light mb-4 p-3 text-center border">
                    <p class="mb-1 text-muted small">Official MicroLend GCash Account</p>
                    <h3 class="fw-bold text-primary mb-1">0917-123-4567</h3>
                    <p class="mb-0 fw-semibold">MicroLend PH Inc.</p>
                </div>

                <?php if ($errors): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0"><?php foreach ($errors as $err) echo '<li>'.e($err).'</li>'; ?></ul>
                    </div>
                <?php endif; ?>

                <form method="post">
                    <input type="hidden" name="schedule_id" value="<?= e($scheduleId) ?>">
                    <input type="hidden" name="loan_id" value="<?= e($loanId) ?>">

                    <div class="mb-3">
                        <label class="form-label fw-semibold">GCash Reference Number (Trace No.)</label>
                        <input type="text" name="reference_no" class="form-control form-control-lg" placeholder="e.g. 1234567890123" required value="<?= e($_POST['reference_no'] ?? '') ?>">
                    </div>

                    <button type="submit" name="submit_gcash" value="1" class="btn btn-success btn-lg w-100 fw-bold">
                        Confirm GCash Payment
                    </button>
                    <a href="/borrower/schedule.php?loan_id=<?= e($loanId) ?>" class="btn btn-outline-secondary w-100 mt-2">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>