<?php
// borrower/pay_bills.php
require_once __DIR__ . '/../includes/auth.php';
requireRole('borrower');
$db = getDB();
$userId = $_SESSION['user_id'];

// Handle Bill Payment submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $billerId = $_POST['biller_id'] ?? '';
    $accountNo = trim($_POST['account_no'] ?? '');
    $amount = (float)($_POST['amount'] ?? 0);

    if (!$billerId || !$accountNo || $amount <= 0) {
        flash('danger', 'Please fill in all required fields with a valid amount.');
        header('Location: /borrower/pay_bills.php');
        exit;
    }

    // Verify biller exists
    $stmt = $db->prepare("SELECT * FROM billers WHERE biller_id = ?");
    $stmt->execute([$billerId]);
    $biller = $stmt->fetch();

    if (!$biller) {
        flash('danger', 'Selected biller does not exist.');
        header('Location: /borrower/pay_bills.php');
        exit;
    }

    // Check borrower wallet balance
    $walletBalance = getWalletBalance($db, $userId);
    if ($walletBalance < $amount) {
        flash('danger', 'Insufficient wallet balance for this bill payment.');
        header('Location: /borrower/pay_bills.php');
        exit;
    }

    try {
        $db->beginTransaction();

        // 1. Deduct from wallet
        $stmt = $db->prepare("UPDATE wallets SET balance = balance - ? WHERE borrower_id = ?");
        $stmt->execute([$amount, $userId]);

        // 2. Record transaction with personal reference code
        $txId = generateUUID();
        $txRef = generateTxReference();
        $description = 'Bill payment to ' . $biller['biller_name'] . ' (Acct: ' . $accountNo . ')';
        
        $stmt = $db->prepare("INSERT INTO transactions (transaction_id, user_id, type, amount, payment_method, reference_no, description) VALUES (?,?, 'BILL_PAYMENT', ?, 'WALLET', ?, ?)");
        $stmt->execute([$txId, $userId, $amount, $txRef, $description]);

        $db->commit();
        flash('success', 'Successfully paid ' . formatMoney($amount) . ' to ' . $biller['biller_name'] . '. Ref: ' . $txRef);
    } catch (Exception $e) {
        $db->rollBack();
        flash('danger', 'Bill payment failed: ' . $e->getMessage());
    }

    header('Location: /borrower/pay_bills.php');
    exit;
}

// Fetch available billers
$stmt = $db->query("SELECT * FROM billers ORDER BY category, biller_name");
$billers = $stmt->fetchAll();

$pageTitle = 'Pay Bills';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="mb-3">
    <a href="/borrower/dashboard.php" class="text-decoration-none"><i class="bi bi-arrow-left"></i> Back to Dashboard</a>
</div>

<div class="row justify-content-center">
    <div class="col-md-7">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-receipt"></i> Utility & Service Bill Payment</h5>
            </div>
            <div class="card-body p-4">
                <div class="alert alert-info py-2 small mb-4">
                    Available Wallet Balance: <strong class="text-success"><?= formatMoney(getWalletBalance($db, $userId)) ?></strong>
                </div>

                <form method="POST" action="">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Select Biller</label>
                        <select name="biller_id" class="form-select" required>
                            <option value="">-- Choose Biller --</option>
                            <?php foreach ($billers as $b): ?>
                                <option value="<?= e($b['biller_id']) ?>">
                                    <?= e($b['biller_name']) ?> (<?= e($b['category']) ?>)
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Account / Contract Number / Mobile No.</label>
                        <input type="text" name="account_no" class="form-control" placeholder="e.g. 1234567890" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label fw-semibold">Amount (₱)</label>
                        <input type="number" step="0.01" min="1" name="amount" class="form-control" placeholder="0.00" required>
                    </div>

                    <button type="submit" class="btn btn-success w-100 fw-bold">
                        <i class="bi bi-check-circle me-1"></i> Pay Bill Now
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>