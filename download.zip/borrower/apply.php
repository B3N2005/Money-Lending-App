<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole('borrower');
$db = getDB();
$userId = $_SESSION['user_id'];

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $amount = filter_var($_POST['amount'] ?? 0, FILTER_VALIDATE_FLOAT);
    $term = filter_var($_POST['repayment_term'] ?? 0, FILTER_VALIDATE_INT);

    if ($amount === false || $amount < 1000) {
        $errors[] = 'Loan amount must be at least ₱1,000.';
    }
    if ($amount > 100000) {
        $errors[] = 'Maximum loan amount is ₱100,000 for this demo.';
    }
    if ($term === false || $term < 1 || $term > 24) {
        $errors[] = 'Repayment term must be between 1 and 24 months.';
    }

    if (empty($errors)) {
        $appId = generateUUID();
        $stmt = $db->prepare("INSERT INTO loan_applications (application_id, borrower_id, amount, repayment_term, status) VALUES (?,?,?,?,'PENDING_REVIEW')");
        $stmt->execute([$appId, $userId, $amount, $term]);
        flash('success', 'Loan application submitted successfully! It is now pending review.');
        echo "<script>window.location.href = '/borrower/dashboard.php';</script>";
        exit;
       
    }
}

$pageTitle = 'Apply for Loan';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card shadow-sm">
            <div class="card-header">
                <h4 class="mb-0">New Loan Application</h4>
            </div>
            <div class="card-body p-4">
                <?php if ($errors): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0"><?php foreach ($errors as $e) echo '<li>'.e($e).'</li>'; ?></ul>
                    </div>
                <?php endif; ?>

                <form method="post" id="loan-form">
                    <div class="mb-3">
                        <label class="form-label">Loan Amount (₱)</label>
                        <input type="number" name="amount" id="amount" class="form-control form-control-lg"
                               min="1000" max="100000" step="100" required
                               value="<?= e($_POST['amount'] ?? '5000') ?>"
                               placeholder="e.g. 5000">
                        <div class="form-text">Minimum ₱1,000 · Maximum ₱100,000</div>
                    </div>

                    <div class="mb-4">
                        <label class="form-label">Repayment Term (months)</label>
                        <select name="repayment_term" id="repayment_term" class="form-select form-select-lg" required>
                            <?php for ($i = 1; $i <= 12; $i++): ?>
                                <option value="<?= $i ?>" <?= (isset($_POST['repayment_term']) && $_POST['repayment_term'] == $i) || (!isset($_POST['repayment_term']) && $i === 3) ? 'selected' : '' ?>>
                                    <?= $i ?> month<?= $i > 1 ? 's' : '' ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <div id="loan-preview" class="preview-box mb-4 d-none"></div>

                    <div class="alert alert-light border small">
                        <strong>Note:</strong> Interest is calculated as <strong>flat 10%</strong> on the principal for the entire term (not compounded). Installments are equal monthly payments.
                    </div>

                    <button type="submit" class="btn btn-primary btn-lg w-100">
                        Submit Application
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
