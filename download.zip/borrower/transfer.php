<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole('borrower');
$db = getDB();
$userId = $_SESSION['user_id'];

$balance = getWalletBalance($db, $userId);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $recipientQuery = trim($_POST['recipient'] ?? '');
    $amount = filter_var($_POST['amount'] ?? 0, FILTER_VALIDATE_FLOAT);
    $note = trim($_POST['note'] ?? 'Fund Transfer');

    if ($recipientQuery === '') $errors[] = 'Please enter recipient username or email.';
    if ($amount === false || $amount <= 0) $errors[] = 'Please enter a valid transfer amount.';
    if ($amount > $balance) $errors[] = 'Insufficient wallet balance.';

    if (empty($errors)) {
        $stmt = $db->prepare("SELECT user_id, full_name, username FROM users WHERE (username = ? OR email = ?) AND user_id != ? AND role = 'borrower'");
        $stmt->execute([$recipientQuery, $recipientQuery, $userId]);
        $recipient = $stmt->fetch();

        if (!$recipient) {
            $errors[] = 'Recipient not found.';
        } else {
            try {
                $db->beginTransaction();

                $sharedRef = generateTxReference();

                $stmt = $db->prepare("UPDATE wallets SET balance = balance - ? WHERE borrower_id = ?");
                $stmt->execute([$amount, $userId]);

                $stmt = $db->prepare("UPDATE wallets SET balance = balance + ? WHERE borrower_id = ?");
                $stmt->execute([$amount, $recipient['user_id']]);

                $txOutId = generateUUID();
                $stmt = $db->prepare("INSERT INTO transactions (transaction_id, user_id, type, amount, payment_method, reference_no, description) VALUES (?,?,'TRANSFER_OUT',?,'WALLET',?,?)");
                $stmt->execute([$txOutId, $userId, $amount, $sharedRef, 'Transfer to ' . $recipient['full_name'] . ' (@' . $recipient['username'] . ') — ' . $note]);

                $txInId = generateUUID();
                $stmt = $db->prepare("INSERT INTO transactions (transaction_id, user_id, type, amount, payment_method, reference_no, description) VALUES (?,?,'TRANSFER_IN',?,'WALLET',?,?)");
                $stmt->execute([$txInId, $recipient['user_id'], $amount, $sharedRef, 'Transfer received from @' . currentUser($db)['username'] . ' — ' . $note]);

                $db->commit();
                flash('success', 'Transferred ' . formatMoney($amount) . ' to ' . $recipient['full_name'] . '!');
                header('Location: /borrower/wallet.php');
                exit;

            } catch (Exception $e) {
                $db->rollBack();
                $errors[] = 'Transfer failed.';
            }
        }
    }
}

$pageTitle = 'Transfer Cash';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0"><i class="bi bi-send me-1"></i> Transfer Cash</h4>
            </div>
            <div class="card-body p-4">
                <div class="alert alert-light border mb-4">
                    <small class="text-muted">Available Wallet Balance:</small>
                    <div class="h4 text-success fw-bold mb-0"><?= formatMoney($balance) ?></div>
                </div>

                <?php if ($errors): ?>
                    <div class="alert alert-danger">
                        <ul class="mb-0"><?php foreach ($errors as $e) echo '<li>'.e($e).'</li>'; ?></ul>
                    </div>
                <?php endif; ?>

                <form method="post">
                    <div class="mb-3">
                        <label class="form-label">Recipient Username or Email</label>
                        <input type="text" name="recipient" class="form-control" required placeholder="e.g. borrower" value="<?= e($_POST['recipient'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Amount (₱)</label>
                        <input type="number" name="amount" class="form-control" step="0.01" min="1" max="<?= $balance ?>" required placeholder="0.00" value="<?= e($_POST['amount'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Note / Message (Optional)</label>
                        <input type="text" name="note" class="form-control" placeholder="e.g. Payment split" value="<?= e($_POST['note'] ?? '') ?>">
                    </div>
                    <button type="submit" class="btn btn-primary w-100 btn-lg">Send Money Now</button>
                    <a href="/borrower/wallet.php" class="btn btn-outline-secondary w-100 mt-2">Back to Wallet</a>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>