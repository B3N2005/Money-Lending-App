<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole('borrower');
$db = getDB();
$userId = $_SESSION['user_id'];

$balance = getWalletBalance($db, $userId);

$stmt = $db->prepare("
    SELECT t.*, l.approved_principal 
    FROM transactions t 
    LEFT JOIN loans l ON t.loan_id = l.loan_id
    WHERE t.user_id = ? 
    ORDER BY t.created_at DESC 
    LIMIT 50
");
$stmt->execute([$userId]);
$transactions = $stmt->fetchAll();

$pageTitle = 'My Wallet';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center">
    <div class="col-lg-8">
        <div class="card mb-3">
            <div class="card-body text-center py-4">
                <div class="stat-label mb-2">Available Wallet Balance</div>
                <div class="wallet-balance mb-2"><?= formatMoney($balance) ?></div>
                <p class="text-secondary mb-0 small">This is your digital wallet balance. Disbursed loans, transfers, and payments appear here.</p>
            </div>
        </div>

        <!-- Quick Banking Action Buttons -->
        <div class="text-center mb-4">
            <a href="/borrower/transfer.php" class="btn btn-primary me-2 fw-semibold">
                <i class="bi bi-send me-1"></i> Transfer Cash
            </a>
            <a href="/borrower/pay_bills.php" class="btn btn-success fw-semibold">
                <i class="bi bi-receipt me-1"></i> Pay Bills
            </a>
        </div>

        <div class="card">
            <div class="card-header">Transaction History</div>
            <div class="card-body p-0">
                <?php if (empty($transactions)): ?>
                    <p class="p-3 text-secondary mb-0">No transactions yet.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Type</th>
                                    <th>Description & Reference</th>
                                    <th class="text-end">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($transactions as $tx): ?>
                                    <tr>
                                        <td class="small"><?= date('M j, Y H:i', strtotime($tx['created_at'])) ?></td>
                                        <td>
                                            <?php if ($tx['type'] === 'DISBURSEMENT'): ?>
                                                <span class="badge bg-success">Disbursement</span>
                                            <?php elseif ($tx['type'] === 'REPAYMENT'): ?>
                                                <?php if (($tx['payment_method'] ?? '') === 'GCASH'): ?>
                                                    <span class="badge bg-primary">GCash Repayment</span>
                                                <?php else: ?>
                                                    <span class="badge bg-info text-dark">Wallet Repayment</span>
                                                <?php endif; ?>
                                            <?php elseif ($tx['type'] === 'TRANSFER_OUT'): ?>
                                                <span class="badge bg-warning text-dark">Transfer Out</span>
                                            <?php elseif ($tx['type'] === 'TRANSFER_IN'): ?>
                                                <span class="badge bg-success">Transfer In</span>
                                            <?php elseif ($tx['type'] === 'BILL_PAYMENT'): ?>
                                                <span class="badge bg-danger">Bill Payment</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary"><?= e($tx['type']) ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="small">
                                            <div><?= e($tx['description'] ?? '—') ?></div>
                                            <?php if (!empty($tx['reference_no'])): ?>
                                                <span class="badge bg-light text-dark border font-monospace mt-1" style="font-size: 0.7rem;">
                                                    Ref: <?= e($tx['reference_no']) ?>
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end fw-semibold <?= in_array($tx['type'], ['DISBURSEMENT', 'TRANSFER_IN']) ? 'text-success' : 'text-danger' ?>">
                                            <?= in_array($tx['type'], ['DISBURSEMENT', 'TRANSFER_IN']) ? '+' : '-' ?><?= formatMoney($tx['amount']) ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>