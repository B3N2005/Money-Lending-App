<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole('borrower');
$db = getDB();
$userId = $_SESSION['user_id'];

// Applications
$stmt = $db->prepare("SELECT * FROM loan_applications WHERE borrower_id = ? ORDER BY created_at DESC LIMIT 10");
$stmt->execute([$userId]);
$applications = $stmt->fetchAll();

// Active loans
$stmt = $db->prepare("SELECT l.*, a.repayment_term FROM loans l JOIN loan_applications a ON l.application_id = a.application_id WHERE l.borrower_id = ? AND l.status IN ('APPROVED','DISBURSED','ACTIVE') ORDER BY l.created_at DESC");
$stmt->execute([$userId]);
$loans = $stmt->fetchAll();

// Next pending installment
$nextInstallment = null;
if ($loans) {
    $loanIds = array_column($loans, 'loan_id');
    $placeholders = implode(',', array_fill(0, count($loanIds), '?'));
    $stmt = $db->prepare("SELECT s.*, l.loan_id FROM repayment_schedules s JOIN loans l ON s.loan_id = l.loan_id WHERE s.loan_id IN ($placeholders) AND s.status = 'PENDING' ORDER BY s.due_date ASC LIMIT 1");
    $stmt->execute($loanIds);
    $nextInstallment = $stmt->fetch();
}

$walletBalance = getWalletBalance($db, $userId);

$pageTitle = 'Borrower Dashboard';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0">Hello, <?= e($_SESSION['full_name']) ?></h2>
    <a href="/borrower/apply.php" class="btn btn-primary">
        <i class="bi bi-plus-lg"></i> Apply for Loan
    </a>
</div>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card stat-card success h-100">
            <div class="card-body">
                <div class="stat-label">Wallet Balance</div>
                <div class="wallet-balance"><?= formatMoney($walletBalance) ?></div>
                <a href="/borrower/wallet.php" class="small">View wallet & transactions →</a>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stat-card warning h-100">
            <div class="card-body">
                <div class="stat-label">Next Installment</div>
                <?php if ($nextInstallment): ?>
                    <div class="stat-value"><?= formatMoney($nextInstallment['installment_amount']) ?></div>
                    <div class="small text-secondary">Due <?= e($nextInstallment['due_date']) ?></div>
                <?php else: ?>
                    <div class="stat-value text-secondary">—</div>
                    <div class="small text-secondary">No pending installments</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stat-card info h-100">
            <div class="card-body">
                <div class="stat-label">Active Loans</div>
                <div class="stat-value"><?= count($loans) ?></div>
                <div class="small text-secondary">Approved / Disbursed / Active</div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header d-flex justify-content-between">
                <span>My Applications</span>
            </div>
            <div class="card-body p-0">
                <?php if (empty($applications)): ?>
                    <p class="p-3 text-secondary mb-0">No applications yet. <a href="/borrower/apply.php">Apply now</a>.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th>Amount</th>
                                    <th>Term</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($applications as $app): ?>
                                    <tr>
                                        <td><?= formatMoney($app['amount']) ?></td>
                                        <td><?= (int)$app['repayment_term'] ?> mo</td>
                                        <td><?= statusBadge($app['status']) ?></td>
                                        <td class="small"><?= date('M j, Y', strtotime($app['created_at'])) ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">Active Loans & Schedule</div>
            <div class="card-body p-0">
                <?php if (empty($loans)): ?>
                    <p class="p-3 text-secondary mb-0">No active loans.</p>
                <?php else: ?>
                    <?php foreach ($loans as $loan): ?>
                        <div class="p-3 border-bottom">
                            <div class="d-flex justify-content-between align-items-start">
                                <div>
                                    <strong><?= formatMoney($loan['approved_principal']) ?></strong>
                                    <span class="ms-2"><?= statusBadge($loan['status']) ?></span>
                                    <div class="small text-secondary">
                                        Interest: <?= formatMoney($loan['flat_interest']) ?> ·
                                        Total: <?= formatMoney($loan['total_repayment']) ?>
                                    </div>
                                </div>
                                <a href="/borrower/schedule.php?loan_id=<?= e($loan['loan_id']) ?>" class="btn btn-sm btn-outline-primary">
                                    View Schedule
                                </a>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
