<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole('borrower');
$db = getDB();
$userId = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_gcash'])) {
    $scheduleId = $_POST['schedule_id'] ?? '';
    $loanId = $_POST['loan_id'] ?? '';
    $refNo = trim($_POST['reference_no'] ?? '');

    if (!$scheduleId || !$loanId || strlen($refNo) < 5) {
        flash('danger', 'Invalid submission or GCash reference number.');
        header('Location: /borrower/dashboard.php');
        exit;
    }

    $stmt = $db->prepare("SELECT * FROM repayment_schedules WHERE schedule_id = ? AND status = 'PENDING'");
    $stmt->execute([$scheduleId]);
    $sched = $stmt->fetch();

    $stmtLoan = $db->prepare("SELECT * FROM loans WHERE loan_id = ? AND borrower_id = ?");
    $stmtLoan->execute([$loanId, $userId]);
    $loan = $stmtLoan->fetch();

    if ($sched && $loan) {
        $stmtCheck = $db->prepare("SELECT transaction_id FROM transactions WHERE reference_no = ?");
        $stmtCheck->execute([$refNo]);
        if ($stmtCheck->fetch()) {
            flash('danger', 'This GCash reference number has already been used.');
            header('Location: /borrower/schedule.php?loan_id=' . urlencode($loanId));
            exit;
        }

        try {
            $db->beginTransaction();

            $stmt = $db->prepare("UPDATE repayment_schedules SET status = 'PAID', paid_at = NOW() WHERE schedule_id = ?");
            $stmt->execute([$scheduleId]);

            $txId = generateUUID();
            $stmt = $db->prepare("INSERT INTO transactions (transaction_id, loan_id, user_id, type, amount, payment_method, reference_no, description) VALUES (?,?,?,?,'REPAYMENT',?,?,?)");
            $stmt->execute([
                $txId, 
                $loanId, 
                $userId, 
                $sched['installment_amount'], 
                'GCASH', 
                $refNo, 
                'GCash Installment #' . $sched['installment_number'] . ' payment'
            ]);

            $poolBalance = getPoolBalance($db);
            $newPool = $poolBalance + (float)$sched['installment_amount'];
            $entryId = generateUUID();
            $stmt = $db->prepare("INSERT INTO lending_pool_ledger (entry_id, type, amount, balance_after, reference_id, notes) VALUES (?,'REPAYMENT',?,?,?,?)");
            $stmt->execute([$entryId, $sched['installment_amount'], $newPool, $loanId, 'GCash Repayment installment #' . $sched['installment_number']]);

            $stmt = $db->prepare("SELECT COUNT(*) FROM repayment_schedules WHERE loan_id = ? AND status = 'PENDING'");
            $stmt->execute([$loanId]);
            if ((int)$stmt->fetchColumn() === 0) {
                $stmt = $db->prepare("UPDATE loans SET status = 'COMPLETED' WHERE loan_id = ?");
                $stmt->execute([$loanId]);
                
                $stmtApp = $db->prepare("SELECT application_id FROM loans WHERE loan_id = ?");
                $stmtApp->execute([$loanId]);
                $loanData = $stmtApp->fetch();
                if ($loanData) {
                    $stmt = $db->prepare("UPDATE loan_applications SET status = 'CLOSED' WHERE application_id = ?");
                    $stmt->execute([$loanData['application_id']]);
                }
            } else {
                $stmt = $db->prepare("UPDATE loans SET status = 'ACTIVE' WHERE loan_id = ? AND status = 'DISBURSED'");
                $stmt->execute([$loanId]);
            }

            $db->commit();
            flash('success', 'GCash payment of ' . formatMoney($sched['installment_amount']) . ' recorded successfully!');
        } catch (Exception $e) {
            $db->rollBack();
            flash('danger', 'Failed to process GCash payment.');
        }
    }

    header('Location: /borrower/schedule.php?loan_id=' . urlencode($loanId));
    exit;
}

header('Location: /borrower/dashboard.php');
exit;