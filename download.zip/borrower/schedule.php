<?php
require_once __DIR__ . '/../includes/auth.php';
requireRole('borrower');
$db = getDB();
$userId = $_SESSION['user_id'];
$loanId = $_GET['loan_id'] ?? '';

if (!$loanId) {
    flash('danger', 'Invalid loan.');
    header('Location: /borrower/dashboard.php');
    exit;
}

$stmt = $db->prepare("SELECT l.*, a.repayment_term FROM loans l JOIN loan_applications a ON l.application_id = a.application_id WHERE l.loan_id = ? AND l.borrower_id = ?");
$stmt->execute([$loanId, $userId]);
$loan = $stmt->fetch();

if (!$loan) {
    flash('danger', 'Loan not found.');
    header('Location: /borrower/dashboard.php');
    exit;
}

$stmt = $db->prepare("SELECT * FROM repayment_schedules WHERE loan_id = ? ORDER BY installment_number ASC");
$stmt->execute([$loanId]);
$schedules = $stmt->fetchAll();

// Handle instant Wallet repayment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['schedule_id']) && !isset($_POST['submit_gcash'])) {
    $scheduleId = $_POST['schedule_id'];
    $stmt = $db->prepare("SELECT * FROM repayment_schedules WHERE schedule_id = ? AND loan_id = ? AND status = 'PENDING'");
    $stmt->execute([$scheduleId, $loanId]);
    $sched = $stmt->fetch();

    if ($sched) {
        $walletBalance = getWalletBalance($db, $userId);
        if ($walletBalance < (float)$sched['installment_amount']) {
            flash('danger', 'Insufficient wallet balance to make this repayment.');
        } else {
            try {
                $db->beginTransaction();

                // Deduct from borrower wallet
                $stmt = $db->prepare("UPDATE wallets SET balance = balance - ? WHERE borrower_id = ?");
                $stmt->execute([$sched['installment_amount'], $userId]);

                // Mark schedule paid
                $stmt = $db->prepare("UPDATE repayment_schedules SET status = 'PAID', paid_at = NOW() WHERE schedule_id = ?");
                $stmt->execute([$scheduleId]);

                // Create transaction with reference code
                $txId = generateUUID();
                $txRef = generateTxReference();
                $stmt = $db->prepare("INSERT INTO transactions (transaction_id, loan_id, user_id, type, amount, payment_method, reference_no, description) VALUES (?,?,?,'REPAYMENT',?,'WALLET',?,?)");
                $stmt->execute([$txId, $loanId, $userId, $sched['installment_amount'], $txRef, 'Installment #' . $sched['installment_number'] . ' wallet payment']);

                // Credit lending pool
                $poolBalance = getPoolBalance($db);
                $newPool = $poolBalance + (float)$sched['installment_amount'];
                $entryId = generateUUID();
                $stmt = $db->prepare("INSERT INTO lending_pool_ledger (entry_id, type, amount, balance_after, reference_id, notes) VALUES (?,'REPAYMENT',?,?,?,?)");
                $stmt->execute([$entryId, $sched['installment_amount'], $newPool, $loanId, 'Repayment installment #' . $sched['installment_number']]);

                // Check loan completion
                $stmt = $db->prepare("SELECT COUNT(*) FROM repayment_schedules WHERE loan_id = ? AND status = 'PENDING'");
                $stmt->execute([$loanId]);
                if ((int)$stmt->fetchColumn() === 0) {
                    $stmt = $db->prepare("UPDATE loans SET status = 'COMPLETED' WHERE loan_id = ?");
                    $stmt->execute([$loanId]);
                    $stmt = $db->prepare("UPDATE loan_applications SET status = 'CLOSED' WHERE application_id = ?");
                    $stmt->execute([$loan['application_id']]);
                } else {
                    $stmt = $db->prepare("UPDATE loans SET status = 'ACTIVE' WHERE loan_id = ? AND status = 'DISBURSED'");
                    $stmt->execute([$loanId]);
                }

                $db->commit();
                flash('success', 'Repayment of ' . formatMoney($sched['installment_amount']) . ' recorded successfully.');
            } catch (Exception $e) {
                $db->rollBack();
                flash('danger', 'Repayment processing failed.');
            }
        }
    }
    header('Location: /borrower/schedule.php?loan_id=' . urlencode($loanId));
    exit;
}

$pageTitle = 'Repayment Schedule';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="mb-3">
    <a href="/borrower/dashboard.php" class="text-decoration-none"><i class="bi bi-arrow-left"></i> Back to Dashboard</a>
</div>

<div class="card mb-4">
    <div class="card-body">
        <div class="row">
            <div class="col-md-3">
                <div class="stat-label">Principal</div>
                <div class="fw-bold"><?= formatMoney($loan['approved_principal']) ?></div>
            </div>
            <div class="col-md-3">
                <div class="stat-label">Flat Interest</div>
                <div class="fw-bold"><?= formatMoney($loan['flat_interest']) ?></div>
            </div>
            <div class="col-md-3">
                <div class="stat-label">Total Repayment</div>
                <div class="fw-bold text-success"><?= formatMoney($loan['total_repayment']) ?></div>
            </div>
            <div class="col-md-3">
                <div class="stat-label">Status</div>
                <div><?= statusBadge($loan['status']) ?></div>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">Installment Schedule</div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Due Date</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($schedules as $s): ?>
                        <tr>
                            <td><?= (int)$s['installment_number'] ?></td>
                            <td><?= e($s['due_date']) ?></td>
                            <td><?= formatMoney($s['installment_amount']) ?></td>
                            <td><?= statusBadge($s['status']) ?></td>
                            <td class="text-end">
                                <?php if ($s['status'] === 'PENDING' && in_array($loan['status'], ['DISBURSED', 'ACTIVE'])): ?>
                                    <!-- Instant Wallet Payment Button with Loading State -->
                                    <form method="post" class="d-inline" onsubmit="this.querySelector('button[type=submit]').disabled = true; this.querySelector('.spinner-border').classList.remove('d-none');">
                                        <input type="hidden" name="schedule_id" value="<?= e($s['schedule_id']) ?>">
                                        <button type="submit" class="btn btn-sm btn-success me-1">
                                            <span class="spinner-border spinner-border-sm d-none me-1" role="status" aria-hidden="true"></span>
                                            Pay via Wallet
                                        </button>
                                    </form>

                                    <!-- GCash Payment Modal Trigger -->
                                    <button type="button" class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#gcashModal<?= e($s['schedule_id']) ?>">
                                        <i class="bi bi-phone"></i> Pay via GCash
                                    </button>

                                    <!-- GCash Payment Modal -->
                                    <div class="modal fade text-start" id="gcashModal<?= e($s['schedule_id']) ?>" tabindex="-1">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="/borrower/pay_gcash_process.php" method="POST">
                                                    <div class="modal-header bg-primary text-white">
                                                        <h5 class="modal-title">GCash Payment — Installment #<?= (int)$s['installment_number'] ?></h5>
                                                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <input type="hidden" name="schedule_id" value="<?= e($s['schedule_id']) ?>">
                                                        <input type="hidden" name="loan_id" value="<?= e($loanId) ?>">

                                                        <div class="alert alert-info py-2 small">
                                                            Send exact amount of <strong><?= formatMoney($s['installment_amount']) ?></strong> to GCash: <strong>0917-123-4567</strong> (MicroLend PH).
                                                        </div>

                                                        <div class="mb-3">
                                                            <label class="form-label fw-semibold">GCash Reference Number (Trace No.)</label>
                                                            <input type="text" name="reference_no" class="form-control" placeholder="e.g. 1234567890123" required>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
                                                        <button type="submit" name="submit_gcash" class="btn btn-success btn-sm fw-bold">Submit GCash Payment</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php elseif ($s['status'] === 'PAID'): ?>
                                    <span class="small text-muted">Paid <?= $s['paid_at'] ? date('M j', strtotime($s['paid_at'])) : '' ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>