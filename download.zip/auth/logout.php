<?php
require_once __DIR__ . '/../includes/auth.php';
$_SESSION = [];
session_destroy();
echo "<script>window.location.href = '/auth/login.php';</script>";
exit;
