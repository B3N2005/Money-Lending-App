<?php
// auth/register.php
require_once __DIR__ . '/../includes/auth.php';

if (!empty($_SESSION['user_id'])) {
    header('Location: /index.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    if ($fullName === '' || $username === '' || $email === '' || $password === '') {
        $error = 'All fields are required.';
    } elseif ($password !== $confirmPassword) {
        $error = 'Passwords do not match.';
    } else {
        $db = getDB();
        
        // Check if username or email already exists
        $stmt = $db->prepare("SELECT user_id FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->fetch()) {
            $error = 'Username or email is already taken.';
        } else {
            try {
                $db->beginTransaction();

                $userId = generateUUID();
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

                // 1. Insert user
                $stmt = $db->prepare("INSERT INTO users (user_id, full_name, username, email, password, role) VALUES (?, ?, ?, ?, ?, 'borrower')");
                $stmt->execute([$userId, $fullName, $username, $email, $hashedPassword]);

                // 2. Initialize digital wallet for the new borrower
                $walletId = generateUUID();
                $stmt = $db->prepare("INSERT INTO wallets (wallet_id, borrower_id, balance) VALUES (?, ?, 0.00)");
                $stmt->execute([$walletId, $userId]);

                $db->commit();

                // ✅ Produces 200 OK
                    flash('success', 'Registration successful!');
                echo "<script>window.location.href = '/auth/login.php';</script>";
                
                exit;
            } catch (Exception $e) {
                $db->rollBack();
                $error = 'Registration failed: ' . $e->getMessage();
            }
        }
    }
}

$pageTitle = 'Register Borrower';
require_once __DIR__ . '/../includes/header.php';
?>

<div class="row justify-content-center mt-4">
    <div class="col-md-6">
        <div class="card shadow-sm">
            <div class="card-body p-4">
                <h3 class="mb-4 text-center">Create Borrower Account</h3>
                <?php if ($error): ?>
                    <div class="alert alert-danger"><?= e($error) ?></div>
                <?php endif; ?>
                
                <form method="post" action="" onsubmit="this.querySelector('button[type=submit]').disabled = true; this.querySelector('.spinner-border').classList.remove('d-none');">
                    <div class="mb-3">
                        <label class="form-label">Full Name</label>
                        <input type="text" name="full_name" class="form-control" required value="<?= e($_POST['full_name'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" name="username" class="form-control" required value="<?= e($_POST['username'] ?? '') ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" required value="<?= e($_POST['email'] ?? '') ?>">
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Confirm Password</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-success w-100 fw-bold position-relative">
                        <span class="spinner-border spinner-border-sm d-none me-1" role="status" aria-hidden="true"></span>
                        Register
                    </button>
                </form>
                <p class="text-center mt-3 mb-0 small">
                    Already have an account? <a href="/auth/login.php">Login</a>
                </p>
            </div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>