-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: sql313.infinityfree.com
-- Generation Time: Oct 22, 2026 at 08:12 AM
-- Server version: 11.4.13-MariaDB
-- PHP Version: 7.2.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `if0_43236489_microlend`
--

-- --------------------------------------------------------

--
-- Table structure for table `billers`
--

CREATE TABLE `billers` (
  `biller_id` char(36) NOT NULL,
  `category` varchar(50) NOT NULL,
  `biller_name` varchar(100) NOT NULL,
  `account_label` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `billers`
--

INSERT INTO `billers` (`biller_id`, `category`, `biller_name`, `account_label`, `created_at`) VALUES
('bl000000-0000-0000-0000-000000000001', 'Electricity', 'MERALCO', 'Contract Account Number', '2026-10-21 15:55:59'),
('bl000000-0000-0000-0000-000000000002', 'Water', 'Manila Water', 'Account ID', '2026-10-21 15:55:59'),
('bl000000-0000-0000-0000-000000000003', 'Telecom', 'Globe Postpaid', 'Mobile Number', '2026-10-21 15:55:59');

-- --------------------------------------------------------

--
-- Table structure for table `lending_pool_ledger`
--

CREATE TABLE `lending_pool_ledger` (
  `entry_id` char(36) NOT NULL,
  `type` enum('DEPOSIT','DISBURSEMENT','REPAYMENT','WITHDRAWAL') NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `balance_after` decimal(12,2) NOT NULL,
  `reference_id` char(36) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `lending_pool_ledger`
--

INSERT INTO `lending_pool_ledger` (`entry_id`, `type`, `amount`, `balance_after`, `reference_id`, `notes`, `created_at`) VALUES
('pool-init-0000-0000-000000000001', 'DEPOSIT', '1000000.00', '1000000.00', NULL, 'Initial System Lending Pool Funding', '2026-10-21 17:16:55'),
('6832156e-5a45-4f9d-b5b7-18a4f6fcbb85', 'DISBURSEMENT', '5000.00', '995000.00', 'bd87f9fb-feda-4819-b7bf-b4e804927f00', 'Disbursement of loan', '2026-10-21 17:18:18'),
('b9e6b095-3f12-4a4e-a386-f0abb35f0486', 'REPAYMENT', '1833.33', '996833.33', 'bd87f9fb-feda-4819-b7bf-b4e804927f00', 'Repayment installment #1', '2026-10-21 17:18:34'),
('fd333ac9-266e-4494-bebc-ca47064025b0', 'REPAYMENT', '1833.33', '998666.66', 'bd87f9fb-feda-4819-b7bf-b4e804927f00', 'Repayment installment #2', '2026-10-21 17:18:39'),
('66f017fd-938b-44c3-a1bc-52bd9767d92f', 'REPAYMENT', '1833.34', '1000500.00', 'bd87f9fb-feda-4819-b7bf-b4e804927f00', 'GCash Repayment installment #3', '2026-10-21 17:20:35'),
('c319ef70-d506-40d9-8c1b-6082fcd77292', 'DISBURSEMENT', '5000.00', '995500.00', '36e00c59-0a85-4ac5-bebc-004321ad8aea', 'Disbursement of loan', '2026-10-22 03:55:52'),
('e8c6712d-390d-4977-893a-c2993de64e45', 'REPAYMENT', '458.33', '995958.33', '36e00c59-0a85-4ac5-bebc-004321ad8aea', 'Repayment installment #1', '2026-10-22 03:56:06'),
('dcea54ed-9fed-4b82-b960-6c54cb3c8cfc', 'REPAYMENT', '458.33', '996416.66', '36e00c59-0a85-4ac5-bebc-004321ad8aea', 'GCash Repayment installment #2', '2026-10-22 03:56:22'),
('080837e3-4fad-4854-8a59-084e01301ee2', 'REPAYMENT', '458.33', '996874.99', '36e00c59-0a85-4ac5-bebc-004321ad8aea', 'Repayment installment #3', '2026-10-22 04:34:39'),
('c2f9bb19-476b-4021-9f14-6fc8b257e5e2', 'REPAYMENT', '458.33', '997333.32', '36e00c59-0a85-4ac5-bebc-004321ad8aea', 'GCash Repayment installment #4', '2026-10-22 04:34:48'),
('d7b3161b-cd71-4034-a221-e517bd967532', 'DISBURSEMENT', '5000.00', '992333.32', '19430096-ee5a-4932-a808-cc909fc6651f', 'Disbursement of loan', '2026-10-22 09:43:50'),
('ada63fcd-ecf4-4a14-b2fb-3f36c415d38a', 'DISBURSEMENT', '5000.00', '987333.32', '802d70b3-2cd9-4a29-9938-a09d0560bae0', 'Disbursement of loan', '2026-10-22 09:44:24'),
('00fa3783-a815-4721-aa58-33182194387c', 'DISBURSEMENT', '5000.00', '982333.32', 'd62bf27f-270b-4ba7-b39e-28252e7ceda3', 'Disbursement of loan', '2026-10-22 10:15:18'),
('6accc4a1-b54d-4ad9-8be1-e8880663a589', 'REPAYMENT', '1833.33', '984166.65', 'd62bf27f-270b-4ba7-b39e-28252e7ceda3', 'Repayment installment #1', '2026-10-22 10:18:26'),
('7cb98fff-270e-4747-928a-7c24671e4818', 'REPAYMENT', '1833.33', '985999.98', 'd62bf27f-270b-4ba7-b39e-28252e7ceda3', 'GCash Repayment installment #2', '2026-10-22 10:18:51');

-- --------------------------------------------------------

--
-- Table structure for table `loans`
--

CREATE TABLE `loans` (
  `loan_id` char(36) NOT NULL,
  `application_id` char(36) NOT NULL,
  `borrower_id` char(36) NOT NULL,
  `approved_principal` decimal(12,2) NOT NULL,
  `flat_interest` decimal(12,2) NOT NULL,
  `total_repayment` decimal(12,2) NOT NULL,
  `interest_rate` decimal(5,2) NOT NULL DEFAULT 10.00,
  `status` enum('APPROVED','DISBURSED','ACTIVE','COMPLETED','DEFAULTED') NOT NULL DEFAULT 'APPROVED',
  `disbursed_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `loans`
--

INSERT INTO `loans` (`loan_id`, `application_id`, `borrower_id`, `approved_principal`, `flat_interest`, `total_repayment`, `interest_rate`, `status`, `disbursed_at`, `created_at`) VALUES
('bd87f9fb-feda-4819-b7bf-b4e804927f00', '2f1134ce-32a5-47be-a77e-557bf0575a5e', '80c8d982-db09-4cdf-8c24-86b321979a48', '5000.00', '500.00', '5500.00', '10.00', 'COMPLETED', '2026-10-21 10:18:18', '2026-10-21 17:18:17'),
('36e00c59-0a85-4ac5-bebc-004321ad8aea', '8312ab1f-0b06-4424-989b-4f5bace7839f', '571b8e7b-4a63-4f35-bdf7-35b34af76cd3', '5000.00', '500.00', '5500.00', '10.00', 'ACTIVE', '2026-10-21 20:55:52', '2026-10-22 03:55:43'),
('802d70b3-2cd9-4a29-9938-a09d0560bae0', '24c38702-ab79-44bf-9d95-2f3141a9cb04', '0707bf6a-8d1a-43a7-a8bb-7c08dbf36e1d', '5000.00', '500.00', '5500.00', '10.00', 'DISBURSED', '2026-10-22 02:44:24', '2026-10-22 09:43:24'),
('19430096-ee5a-4932-a808-cc909fc6651f', '32fceb8d-ab5e-4f77-a7a1-6bd9d116cf20', '0707bf6a-8d1a-43a7-a8bb-7c08dbf36e1d', '5000.00', '500.00', '5500.00', '10.00', 'DISBURSED', '2026-10-22 02:43:50', '2026-10-22 09:43:47'),
('d62bf27f-270b-4ba7-b39e-28252e7ceda3', '828c6a26-d9e8-45f6-bc6c-fec089935b14', 'eb44d56f-1f69-4a01-b315-a8d165424d30', '5000.00', '500.00', '5500.00', '10.00', 'ACTIVE', '2026-10-22 03:15:18', '2026-10-22 10:15:00');

-- --------------------------------------------------------

--
-- Table structure for table `loan_applications`
--

CREATE TABLE `loan_applications` (
  `application_id` char(36) NOT NULL,
  `borrower_id` char(36) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `repayment_term` int(11) NOT NULL,
  `status` enum('PENDING_REVIEW','APPROVED','REJECTED','DISBURSED','CLOSED') NOT NULL DEFAULT 'PENDING_REVIEW',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `loan_applications`
--

INSERT INTO `loan_applications` (`application_id`, `borrower_id`, `amount`, `repayment_term`, `status`, `created_at`) VALUES
('2f1134ce-32a5-47be-a77e-557bf0575a5e', '80c8d982-db09-4cdf-8c24-86b321979a48', '5000.00', 3, 'CLOSED', '2026-10-21 17:18:00'),
('7f61ebf1-b2fe-4a02-8c93-3f6f71774785', '64f44afb-a158-43e6-81ec-39fe6747ebfe', '5000.00', 3, 'REJECTED', '2026-10-21 17:49:10'),
('8312ab1f-0b06-4424-989b-4f5bace7839f', '571b8e7b-4a63-4f35-bdf7-35b34af76cd3', '5000.00', 12, 'DISBURSED', '2026-10-22 03:54:49'),
('24c38702-ab79-44bf-9d95-2f3141a9cb04', '0707bf6a-8d1a-43a7-a8bb-7c08dbf36e1d', '5000.00', 3, 'DISBURSED', '2026-10-22 09:31:05'),
('32fceb8d-ab5e-4f77-a7a1-6bd9d116cf20', '0707bf6a-8d1a-43a7-a8bb-7c08dbf36e1d', '5000.00', 10, 'DISBURSED', '2026-10-22 09:42:21'),
('828c6a26-d9e8-45f6-bc6c-fec089935b14', 'eb44d56f-1f69-4a01-b315-a8d165424d30', '5000.00', 3, 'DISBURSED', '2026-10-22 09:59:21'),
('db6f5bb1-1819-4aa2-bfa2-a140d723cc17', 'eb44d56f-1f69-4a01-b315-a8d165424d30', '5000.00', 3, 'PENDING_REVIEW', '2026-10-22 10:00:28'),
('9eb886bc-cf1e-4491-bfc9-609d251dbdd0', 'eb44d56f-1f69-4a01-b315-a8d165424d30', '5000.00', 3, 'PENDING_REVIEW', '2026-10-22 10:14:51');

-- --------------------------------------------------------

--
-- Table structure for table `repayment_schedules`
--

CREATE TABLE `repayment_schedules` (
  `schedule_id` char(36) NOT NULL,
  `loan_id` char(36) NOT NULL,
  `installment_number` int(11) NOT NULL,
  `due_date` date NOT NULL,
  `installment_amount` decimal(12,2) NOT NULL,
  `status` enum('PENDING','PAID','OVERDUE') NOT NULL DEFAULT 'PENDING',
  `paid_at` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `repayment_schedules`
--

INSERT INTO `repayment_schedules` (`schedule_id`, `loan_id`, `installment_number`, `due_date`, `installment_amount`, `status`, `paid_at`) VALUES
('9e44a3a4-d292-40dc-9544-4d9c5e879238', 'bd87f9fb-feda-4819-b7bf-b4e804927f00', 1, '2026-11-01', '1833.33', 'PAID', '2026-10-21 10:18:34'),
('27c629b0-ea3e-481c-8941-b6eb20e898cc', 'bd87f9fb-feda-4819-b7bf-b4e804927f00', 2, '2026-12-01', '1833.33', 'PAID', '2026-10-21 10:18:39'),
('d99dc2f1-892a-426e-9925-aa45e7a97b2b', 'bd87f9fb-feda-4819-b7bf-b4e804927f00', 3, '2027-01-01', '1833.34', 'PAID', '2026-10-21 10:20:35'),
('533bb431-1e14-4eae-90fe-a6e6e06f5c85', '36e00c59-0a85-4ac5-bebc-004321ad8aea', 1, '2026-11-01', '458.33', 'PAID', '2026-10-21 20:56:06'),
('ddf2f19d-e9d1-477f-8add-bfeaeed20ac2', '36e00c59-0a85-4ac5-bebc-004321ad8aea', 2, '2026-12-01', '458.33', 'PAID', '2026-10-21 20:56:22'),
('770212ea-aed8-46fe-8e96-0e862f844867', '36e00c59-0a85-4ac5-bebc-004321ad8aea', 3, '2027-01-01', '458.33', 'PAID', '2026-10-21 21:34:39'),
('d612b682-342f-4fb2-9a9a-94b9479410bd', '36e00c59-0a85-4ac5-bebc-004321ad8aea', 4, '2027-02-01', '458.33', 'PAID', '2026-10-21 21:34:48'),
('509a9b4e-335b-40b6-9179-a5a88e8d2e8e', '36e00c59-0a85-4ac5-bebc-004321ad8aea', 5, '2027-03-01', '458.33', 'PENDING', NULL),
('f9c5d769-29fe-4138-a76e-053f9d0b2ca0', '36e00c59-0a85-4ac5-bebc-004321ad8aea', 6, '2027-04-01', '458.33', 'PENDING', NULL),
('7a02f616-01bf-490e-babe-512086063a7b', '36e00c59-0a85-4ac5-bebc-004321ad8aea', 7, '2027-05-01', '458.33', 'PENDING', NULL),
('043ccde7-1617-46b4-9671-0e20a9edab9a', '36e00c59-0a85-4ac5-bebc-004321ad8aea', 8, '2027-06-01', '458.33', 'PENDING', NULL),
('4c415dc2-f7b5-4c0d-9d4e-cec026221b39', '36e00c59-0a85-4ac5-bebc-004321ad8aea', 9, '2027-07-01', '458.33', 'PENDING', NULL),
('86d04392-8d39-4798-8c1b-e6f9fdfe8efb', '36e00c59-0a85-4ac5-bebc-004321ad8aea', 10, '2027-08-01', '458.33', 'PENDING', NULL),
('ed603bc9-6c9f-4537-8f04-12a1fc6ff2ca', '36e00c59-0a85-4ac5-bebc-004321ad8aea', 11, '2027-09-01', '458.33', 'PENDING', NULL),
('46d436db-5d48-4b73-aacc-7f2d07bcb648', '36e00c59-0a85-4ac5-bebc-004321ad8aea', 12, '2027-10-01', '458.37', 'PENDING', NULL),
('d2f0e37d-d194-464b-918a-e1bd8ada07aa', '802d70b3-2cd9-4a29-9938-a09d0560bae0', 1, '2026-11-01', '1833.33', 'PENDING', NULL),
('aa7905cd-281d-465b-8e36-f691821997ea', '802d70b3-2cd9-4a29-9938-a09d0560bae0', 2, '2026-12-01', '1833.33', 'PENDING', NULL),
('f03ebb2f-336a-4ede-8f20-9c388aa7962f', '802d70b3-2cd9-4a29-9938-a09d0560bae0', 3, '2027-01-01', '1833.34', 'PENDING', NULL),
('dc94b0c5-a8bc-42a1-9847-ac49234b465b', '19430096-ee5a-4932-a808-cc909fc6651f', 1, '2026-11-01', '550.00', 'PENDING', NULL),
('7ffa8db1-23cb-47a9-8c37-90e09c773c1e', '19430096-ee5a-4932-a808-cc909fc6651f', 2, '2026-12-01', '550.00', 'PENDING', NULL),
('0fdceb5b-39f3-4a33-a976-13c25214d39f', '19430096-ee5a-4932-a808-cc909fc6651f', 3, '2027-01-01', '550.00', 'PENDING', NULL),
('67de03a3-bff4-4c8b-b969-d612b594e731', '19430096-ee5a-4932-a808-cc909fc6651f', 4, '2027-02-01', '550.00', 'PENDING', NULL),
('a95197d0-1c4b-4765-8c90-dcaba55d9ea0', '19430096-ee5a-4932-a808-cc909fc6651f', 5, '2027-03-01', '550.00', 'PENDING', NULL),
('a655c589-341a-40e6-be23-0112f778ebe0', '19430096-ee5a-4932-a808-cc909fc6651f', 6, '2027-04-01', '550.00', 'PENDING', NULL),
('a930d7c5-42e5-41d1-b4c2-ff0c2a3022ab', '19430096-ee5a-4932-a808-cc909fc6651f', 7, '2027-05-01', '550.00', 'PENDING', NULL),
('8f061983-3c59-45e2-bc0e-361a8098cf7d', '19430096-ee5a-4932-a808-cc909fc6651f', 8, '2027-06-01', '550.00', 'PENDING', NULL),
('d80c645d-ac84-43d0-83e9-6b21611aefdb', '19430096-ee5a-4932-a808-cc909fc6651f', 9, '2027-07-01', '550.00', 'PENDING', NULL),
('43f337d4-2327-4073-baf4-2d5f324a1df1', '19430096-ee5a-4932-a808-cc909fc6651f', 10, '2027-08-01', '550.00', 'PENDING', NULL),
('5245957b-4b55-4275-bfcc-bf6435b7aa1a', 'd62bf27f-270b-4ba7-b39e-28252e7ceda3', 1, '2026-11-01', '1833.33', 'PAID', '2026-10-22 03:18:26'),
('479faaa3-8c24-46c2-85c5-f151ed6614a1', 'd62bf27f-270b-4ba7-b39e-28252e7ceda3', 2, '2026-12-01', '1833.33', 'PAID', '2026-10-22 03:18:51'),
('484b9bea-bf41-4bdd-bab8-ccf6c4d72d7b', 'd62bf27f-270b-4ba7-b39e-28252e7ceda3', 3, '2027-01-01', '1833.34', 'PENDING', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `transaction_id` char(36) NOT NULL,
  `loan_id` char(36) DEFAULT NULL,
  `user_id` char(36) NOT NULL,
  `type` enum('DISBURSEMENT','REPAYMENT','POOL_CREDIT','POOL_DEBIT','TRANSFER_OUT','TRANSFER_IN','BILL_PAYMENT') NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `payment_method` varchar(30) DEFAULT 'WALLET',
  `reference_no` varchar(100) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`transaction_id`, `loan_id`, `user_id`, `type`, `amount`, `payment_method`, `reference_no`, `description`, `created_at`) VALUES
('fe29eecc-790a-4195-939b-fa23f188b4b4', 'bd87f9fb-feda-4819-b7bf-b4e804927f00', '80c8d982-db09-4cdf-8c24-86b321979a48', 'DISBURSEMENT', '5000.00', 'WALLET', 'REF-A494EE-9216', 'Loan disbursement to wallet', '2026-10-21 17:18:18'),
('f1bd8f54-2ef0-447b-bf31-fc4fa4dfa027', 'bd87f9fb-feda-4819-b7bf-b4e804927f00', '80c8d982-db09-4cdf-8c24-86b321979a48', 'REPAYMENT', '1833.33', 'WALLET', 'REF-DD4F70-9692', 'Installment #1 wallet payment', '2026-10-21 17:18:34'),
('10d5a4f9-0504-45e0-9eae-bfacaf3f4f8f', 'bd87f9fb-feda-4819-b7bf-b4e804927f00', '80c8d982-db09-4cdf-8c24-86b321979a48', 'REPAYMENT', '1833.33', 'WALLET', 'REF-49CDBD-9912', 'Installment #2 wallet payment', '2026-10-21 17:18:39'),
('8b55cc9f-8ec3-4e94-a90b-e83a90ed22f9', 'bd87f9fb-feda-4819-b7bf-b4e804927f00', '80c8d982-db09-4cdf-8c24-86b321979a48', '', '0.00', 'GCASH', '0917-123-4567', 'GCash Installment #3 payment', '2026-10-21 17:20:35'),
('18e064ac-d5d8-491a-8a6f-7055c58ef285', NULL, '80c8d982-db09-4cdf-8c24-86b321979a48', 'BILL_PAYMENT', '100.00', 'WALLET', 'REF-65F1B9-3240', 'Bill payment to MERALCO (Acct: 41241231231)', '2026-10-21 17:26:27'),
('fc2e1e03-6585-4f2e-a08a-537077dcad5b', NULL, '80c8d982-db09-4cdf-8c24-86b321979a48', 'TRANSFER_OUT', '100.00', 'WALLET', 'REF-239C48-6067', 'Transfer to Demo Borrower (@borrower) — ', '2026-10-21 17:26:49'),
('7de4c489-c008-4843-b72d-aba9324c3de7', NULL, 'borrower-uuid-000-000-000000000002', 'TRANSFER_IN', '100.00', 'WALLET', 'REF-239C48-6067', 'Transfer received from @Zerep — ', '2026-10-21 17:26:49'),
('93dd681e-ac9a-4f86-9e29-50acaae5fd45', '36e00c59-0a85-4ac5-bebc-004321ad8aea', '571b8e7b-4a63-4f35-bdf7-35b34af76cd3', 'DISBURSEMENT', '5000.00', 'WALLET', 'REF-A8D85C-1739', 'Loan disbursement to wallet', '2026-10-22 03:55:52'),
('da3d2c3b-aefd-4686-96af-4d00f2ff5f39', '36e00c59-0a85-4ac5-bebc-004321ad8aea', '571b8e7b-4a63-4f35-bdf7-35b34af76cd3', 'REPAYMENT', '458.33', 'WALLET', 'REF-7F70CC-3631', 'Installment #1 wallet payment', '2026-10-22 03:56:06'),
('b29139f1-acd6-465f-bda9-b5a9e374cf8a', '36e00c59-0a85-4ac5-bebc-004321ad8aea', '571b8e7b-4a63-4f35-bdf7-35b34af76cd3', '', '0.00', 'GCASH', '09652960441', 'GCash Installment #2 payment', '2026-10-22 03:56:22'),
('a10ab35f-2e12-4f65-b67e-11eef4e61e8f', '36e00c59-0a85-4ac5-bebc-004321ad8aea', '571b8e7b-4a63-4f35-bdf7-35b34af76cd3', 'REPAYMENT', '458.33', 'WALLET', 'REF-E9266E-6187', 'Installment #3 wallet payment', '2026-10-22 04:34:39'),
('a9ac19c0-e450-47f9-a793-7d8f7cb64cbb', '36e00c59-0a85-4ac5-bebc-004321ad8aea', '571b8e7b-4a63-4f35-bdf7-35b34af76cd3', '', '0.00', 'GCASH', '09652950441', 'GCash Installment #4 payment', '2026-10-22 04:34:48'),
('559c6ad0-a13c-40c2-9732-f579f1170975', '19430096-ee5a-4932-a808-cc909fc6651f', '0707bf6a-8d1a-43a7-a8bb-7c08dbf36e1d', 'DISBURSEMENT', '5000.00', 'WALLET', 'REF-FE3871-2189', 'Loan disbursement to wallet', '2026-10-22 09:43:50'),
('6ffb922f-8353-4df6-90d9-27f3d4a2d873', '802d70b3-2cd9-4a29-9938-a09d0560bae0', '0707bf6a-8d1a-43a7-a8bb-7c08dbf36e1d', 'DISBURSEMENT', '5000.00', 'WALLET', 'REF-F2679A-9143', 'Loan disbursement to wallet', '2026-10-22 09:44:24'),
('a21a7333-1e7c-4fee-8d3f-bfd93ebf8401', 'd62bf27f-270b-4ba7-b39e-28252e7ceda3', 'eb44d56f-1f69-4a01-b315-a8d165424d30', 'DISBURSEMENT', '5000.00', 'WALLET', 'REF-8A503B-3944', 'Loan disbursement to wallet', '2026-10-22 10:15:18'),
('820a330c-e4df-4245-9fad-ca6aaf8aa88f', NULL, 'eb44d56f-1f69-4a01-b315-a8d165424d30', 'BILL_PAYMENT', '1000.00', 'WALLET', 'REF-BE9B91-3739', 'Bill payment to MERALCO (Acct: 41241231231)', '2026-10-22 10:16:34'),
('aef9cca2-3d22-4e6d-a04e-f43e024106c8', 'd62bf27f-270b-4ba7-b39e-28252e7ceda3', 'eb44d56f-1f69-4a01-b315-a8d165424d30', 'REPAYMENT', '1833.33', 'WALLET', 'REF-50854D-3511', 'Installment #1 wallet payment', '2026-10-22 10:18:26'),
('65fc54a4-26d5-4557-9ab8-04c5d522f075', 'd62bf27f-270b-4ba7-b39e-28252e7ceda3', 'eb44d56f-1f69-4a01-b315-a8d165424d30', '', '0.00', 'GCASH', '09757012939', 'GCash Installment #2 payment', '2026-10-22 10:18:51');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` char(36) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('borrower','admin') NOT NULL DEFAULT 'borrower',
  `status` varchar(20) DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `full_name`, `username`, `email`, `password`, `role`, `status`, `created_at`) VALUES
('781426c1-b272-4f26-8798-353c6ee67045', 'ED BENEDICT A. PEREZ', 'Perez', 'gamingytt78@gmail.com', '$2y$12$pU85NSE/FWbv3gJGv1UjzeBJaiIcU5D4vMNMrp1223ulFRUiQ3QNe', 'borrower', 'active', '2026-10-21 16:59:40'),
('borrower-uuid-000-000-000000000002', 'Demo Borrower', 'borrower', 'borrower@microlend.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'borrower', 'active', '2026-10-21 17:15:56'),
('admin-uuid-0000-0000-000000000001', 'System Administrator', 'admin', 'admin@microlend.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 'active', '2026-10-21 17:15:56'),
('0707bf6a-8d1a-43a7-a8bb-7c08dbf36e1d', 'zerep123', 'Perez123', 'Gasdadsa@gmail.com', '$2y$12$E.CvxT/wFNj9KAvDoFdzguE9V.0CBTNYWOHX05dIjOnqZVnFikcci', 'borrower', 'active', '2026-10-22 09:30:15'),
('17c114fc-bfdf-43ac-9b6b-d46f4c894bd8', 'Pasadasd', 'perez1233', 'dasdsadsadsada@gmail.com', '$2y$12$DSxnlrqVNETvsQzvovHPD.BJJed/iQFoXh65v5TivlnJw/VVKdKjq', 'borrower', 'active', '2026-10-22 09:52:56'),
('eb44d56f-1f69-4a01-b315-a8d165424d30', 'legara', 'legara1', 'legara@gmail.com', '$2y$12$9hrUWLBwt2CPfFHu.fZ2XOdZAt5EEd08UwOfLumT7COuQ1TcgEp9G', 'borrower', 'active', '2026-10-22 09:57:40'),
('d575b06c-3e19-4a19-8bef-f2529fded951', 'perez123', 'perez3211', 'gamingytt798@gmail.com', '$2y$12$IIwOIseDKuoxg0TlAsj91ubrzZru72PHtLyFQwaPMBoIx7tuMt0sW', 'borrower', 'active', '2026-10-22 10:10:53');

-- --------------------------------------------------------

--
-- Table structure for table `wallets`
--

CREATE TABLE `wallets` (
  `wallet_id` char(36) NOT NULL,
  `borrower_id` char(36) NOT NULL,
  `balance` decimal(12,2) NOT NULL DEFAULT 0.00,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `wallets`
--

INSERT INTO `wallets` (`wallet_id`, `borrower_id`, `balance`, `updated_at`) VALUES
('681127b9-0120-4eb0-9366-934603d37108', '781426c1-b272-4f26-8798-353c6ee67045', '0.00', '2026-10-21 16:59:40'),
('wallet-uuid-000-000-000000000002', 'borrower-uuid-000-000-000000000002', '10100.00', '2026-10-21 17:26:49'),
('17743ba7-f6e0-4777-9d5e-85dc6f78be22', '80c8d982-db09-4cdf-8c24-86b321979a48', '1133.34', '2026-10-21 17:26:49'),
('039f0bde-55b4-4828-8b8e-cc0802f9e96a', '64f44afb-a158-43e6-81ec-39fe6747ebfe', '0.00', '2026-10-21 17:39:27'),
('51f1d871-608a-463b-ae2e-947f5c391a1f', '571b8e7b-4a63-4f35-bdf7-35b34af76cd3', '4083.34', '2026-10-22 04:34:39'),
('37479c32-0818-4c11-aee6-d36c5567dcfe', '73fa2c5b-8a80-4cf8-b823-2ddfd2081ced', '0.00', '2026-10-22 09:15:17'),
('6460ab1d-e992-42e0-a2b4-840b7ca12934', '37730bcc-b761-4290-89b4-d5d4a06b4ab0', '0.00', '2026-10-22 09:20:27'),
('5e5fcd23-8aa7-41b0-b8e6-007742f66d74', '0707bf6a-8d1a-43a7-a8bb-7c08dbf36e1d', '10000.00', '2026-10-22 09:44:24'),
('bf9ed2e0-900d-4fcd-b17b-f59064c70c5f', '17c114fc-bfdf-43ac-9b6b-d46f4c894bd8', '0.00', '2026-10-22 09:52:56'),
('cc7aead8-73f3-4e50-a622-534369e57818', 'eb44d56f-1f69-4a01-b315-a8d165424d30', '2166.67', '2026-10-22 10:18:26'),
('29c2d62a-cfe7-44a2-a84c-dff6cd23cf4a', 'd575b06c-3e19-4a19-8bef-f2529fded951', '0.00', '2026-10-22 10:10:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `billers`
--
ALTER TABLE `billers`
  ADD PRIMARY KEY (`biller_id`);

--
-- Indexes for table `lending_pool_ledger`
--
ALTER TABLE `lending_pool_ledger`
  ADD PRIMARY KEY (`entry_id`);

--
-- Indexes for table `loans`
--
ALTER TABLE `loans`
  ADD PRIMARY KEY (`loan_id`),
  ADD KEY `application_id` (`application_id`),
  ADD KEY `borrower_id` (`borrower_id`);

--
-- Indexes for table `loan_applications`
--
ALTER TABLE `loan_applications`
  ADD PRIMARY KEY (`application_id`),
  ADD KEY `borrower_id` (`borrower_id`);

--
-- Indexes for table `repayment_schedules`
--
ALTER TABLE `repayment_schedules`
  ADD PRIMARY KEY (`schedule_id`),
  ADD KEY `loan_id` (`loan_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`),
  ADD KEY `loan_id` (`loan_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_username_email` (`username`,`email`);

--
-- Indexes for table `wallets`
--
ALTER TABLE `wallets`
  ADD PRIMARY KEY (`wallet_id`),
  ADD UNIQUE KEY `borrower_id` (`borrower_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
